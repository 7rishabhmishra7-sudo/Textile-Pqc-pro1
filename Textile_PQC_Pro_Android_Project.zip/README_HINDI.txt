TEXTILE PQC PRO - ANDROID PROJECT

यह अलग Android app है। इसका package ID com.rishabh.textilepqcpro है, इसलिए Textile QA Pro से अलग install होगा।

इसमें:
- Weaving PQC Excel upload
- Buyer, Invoice, GSM, Invoice Quantity, दोनों loss %, Applied Net Quantity input
- Process PQC blank template app में bundled है
- Generated_Process_PQC.xlsx डाउनलोड/सेव करने की सुविधा

APK बनाने के लिए:
1. इस ZIP को GitHub repository में upload करें (सभी files/folders सहित)।
2. GitHub में Actions tab खोलें।
3. "Build Textile PQC Pro APK" workflow चुनें।
4. Run workflow दबाएं।
5. Run पूरा होने पर Artifacts में Textile-PQC-Pro-debug-apk डाउनलोड करें।
6. ZIP artifact extract करके app-debug.apk Android phone में install करें।

ध्यान:
ExcelJS CDN से लोड होता है, इसलिए Excel पढ़ने/बनाने के समय internet connection चाहिए।
पहली बार Android install करते समय browser/file access permission मांगी जा सकती है।
